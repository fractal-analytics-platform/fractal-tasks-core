This submodule includes development tools, especially useful to create the JSON
Schemas for task arguments.
